# SAC OS

A macOS-inspired desktop environment written in Rust with [egui](https://github.com/emilk/egui).
It runs as a normal window on Linux, macOS, and Windows. It is not a system launcher yet.

## Run

```
cargo run --release
```

You need a recent stable Rust toolchain (install from https://rustup.rs).

## Features

- Menu bar with the SAC logo menu, the active app's name, Wi-Fi, battery, and a clock.
- Floating dock with hover magnification and running-app indicators.
- Windows with red, yellow, and green traffic-light buttons (close, minimize, zoom).
- Drag title bars to move, double-click to zoom, drag to the screen edges to snap to halves.
- Drag the bottom-right corner to resize.
- Apps: About, Notes, Calculator, Settings (theme and wallpaper), Activity Monitor.
- Spotlight search (Cmd+Space) and keyboard shortcuts. See the About window for the full list.

## Not included yet

- Wi-Fi and battery values are placeholders.
- Activity Monitor shows open windows, not real per-process data.
- Kotlin and Android integration will be added later.
