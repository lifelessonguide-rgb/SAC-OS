/// A simple left-to-right calculator, like the basic mode of macOS Calculator.
pub struct Calculator {
    display: String,
    acc: Option<f64>,
    op: Option<char>,
    fresh: bool,
}

impl Calculator {
    pub fn new() -> Self {
        Self {
            display: "0".to_string(),
            acc: None,
            op: None,
            fresh: true,
        }
    }

    pub fn display(&self) -> &str {
        &self.display
    }

    fn value(&self) -> f64 {
        self.display.parse().unwrap_or(0.0)
    }

    /// Sets the display to a result. Returns false (and shows "Error") if not finite.
    fn show(&mut self, r: f64) -> bool {
        if r.is_finite() {
            self.display = fmt(r);
            true
        } else {
            self.display = "Error".to_string();
            false
        }
    }

    pub fn digit(&mut self, c: char) {
        if self.fresh {
            self.display = "0".to_string();
            self.fresh = false;
        }
        if c == '.' {
            if self.display.contains('.') {
                return;
            }
        } else if self.display == "0" {
            self.display.clear();
        }
        if self.display.len() >= 15 {
            return;
        }
        self.display.push(c);
    }

    pub fn op(&mut self, op: char) {
        if let (Some(a), Some(p)) = (self.acc, self.op) {
            if !self.fresh {
                let r = apply(a, self.value(), p);
                if !self.show(r) {
                    self.acc = None;
                    self.op = None;
                    self.fresh = true;
                    return;
                }
                self.acc = Some(r);
            }
        } else {
            self.acc = Some(self.value());
        }
        self.op = Some(op);
        self.fresh = true;
    }

    pub fn equals(&mut self) {
        if let (Some(a), Some(p)) = (self.acc, self.op) {
            let r = apply(a, self.value(), p);
            self.show(r);
            self.acc = None;
            self.op = None;
            self.fresh = true;
        }
    }

    pub fn percent(&mut self) {
        let v = self.value() / 100.0;
        self.show(v);
        self.fresh = true;
    }

    pub fn backspace(&mut self) {
        if self.fresh {
            return;
        }
        self.display.pop();
        if self.display.is_empty() {
            self.display = "0".to_string();
        }
    }

    pub fn clear(&mut self) {
        *self = Self::new();
    }
}

fn apply(a: f64, b: f64, op: char) -> f64 {
    match op {
        '+' => a + b,
        '-' => a - b,
        '*' => a * b,
        '/' => {
            if b == 0.0 {
                f64::NAN
            } else {
                a / b
            }
        }
        _ => b,
    }
}

fn fmt(v: f64) -> String {
    let s = format!("{:.9}", v);
    let t = s.trim_end_matches('0').trim_end_matches('.');
    if t.is_empty() || t == "-0" {
        "0".to_string()
    } else {
        t.to_string()
    }
}
