use eframe::egui::{self, RichText, TextEdit, Ui, Vec2};

use crate::calculator::Calculator;
use crate::desktop::{Action, AppKind, Settings, Window};
use crate::theme::{Mode, Theme, WALLPAPERS};

/// Snapshot of desktop state shown by Activity Monitor.
pub struct MonitorData {
    pub windows: Vec<(u64, String, bool)>,
    pub fps: f32,
    pub uptime_secs: u64,
}

/// Renders the contents of one window.
pub fn render(
    ui: &mut Ui,
    win: &mut Window,
    monitor: &MonitorData,
    settings: &mut Settings,
    theme: &Theme,
    actions: &mut Vec<Action>,
) {
    match win.kind {
        AppKind::About => about(ui, theme),
        AppKind::Notes => notes(ui, &mut win.notes, theme),
        AppKind::Calculator => calculator(ui, &mut win.calc, theme),
        AppKind::Settings => settings_panel(ui, settings, theme),
        AppKind::Monitor => monitor_panel(ui, monitor, theme, actions),
    }
}

fn about(ui: &mut Ui, theme: &Theme) {
    ui.vertical_centered(|ui| {
        ui.add_space(12.0);
        ui.label(RichText::new("SAC OS").size(28.0).strong().color(theme.text));
        ui.label(RichText::new("Version 0.1.0").color(theme.subtle));
        ui.add_space(10.0);
        ui.label(
            RichText::new("A macOS-inspired desktop, built in Rust with egui.").color(theme.text),
        );
    });
    ui.add_space(14.0);
    ui.label(RichText::new("Keyboard shortcuts").strong().color(theme.text));
    ui.label(RichText::new("Cmd is Ctrl on Linux and Windows.").color(theme.subtle));
    for line in [
        "Cmd+Space: Spotlight search",
        "Cmd+N: new Notes window",
        "Cmd+W: close window",
        "Cmd+M: minimize window",
        "Cmd+Tab: switch windows",
        "Cmd+,: Settings",
        "Cmd+Option+Esc or Ctrl+Alt+Delete: Activity Monitor",
        "Cmd+Q: quit SAC OS",
        "Esc: close Spotlight",
    ] {
        ui.label(RichText::new(line).color(theme.text));
    }
    ui.add_space(8.0);
    ui.label(RichText::new("Mouse").strong().color(theme.text));
    ui.label(
        RichText::new(
            "Drag title bars to move. Double-click a title bar to zoom. \
             Drag a window to the left or right edge to snap it to half the screen. \
             Drag the bottom-right corner to resize.",
        )
        .color(theme.subtle),
    );
}

fn notes(ui: &mut Ui, text: &mut String, theme: &Theme) {
    let size = ui.available_size();
    ui.add_sized(
        size,
        TextEdit::multiline(text)
            .hint_text("Start typing…")
            .desired_width(f32::INFINITY)
            .text_color(theme.text),
    );
}

fn calculator(ui: &mut Ui, calc: &mut Calculator, theme: &Theme) {
    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
        ui.label(RichText::new(calc.display()).size(36.0).color(theme.text));
    });
    ui.add_space(10.0);

    let rows: [[&str; 4]; 5] = [
        ["C", "Del", "%", "÷"],
        ["7", "8", "9", "×"],
        ["4", "5", "6", "-"],
        ["1", "2", "3", "+"],
        ["0", ".", "", "="],
    ];

    egui::Grid::new("calc_grid")
        .spacing([8.0, 8.0])
        .show(ui, |ui| {
            for row in rows.iter() {
                for label in row.iter() {
                    if label.is_empty() {
                        ui.allocate_space(Vec2::new(64.0, 48.0));
                        continue;
                    }
                    let is_op = matches!(*label, "÷" | "×" | "-" | "+" | "=");
                    let mut button = egui::Button::new(RichText::new(*label).size(20.0))
                        .min_size(Vec2::new(64.0, 48.0));
                    if is_op {
                        button = button.fill(theme.accent);
                    }
                    if ui.add(button).clicked() {
                        press(calc, *label);
                    }
                }
                ui.end_row();
            }
        });
}

/// Shared by on-screen buttons. Keyboard input is handled in desktop.rs.
fn press(calc: &mut Calculator, key: &str) {
    match key {
        "C" => calc.clear(),
        "Del" => calc.backspace(),
        "%" => calc.percent(),
        "÷" => calc.op('/'),
        "×" => calc.op('*'),
        "-" => calc.op('-'),
        "+" => calc.op('+'),
        "=" => calc.equals(),
        digit => {
            for c in digit.chars() {
                calc.digit(c);
            }
        }
    }
}

fn settings_panel(ui: &mut Ui, settings: &mut Settings, theme: &Theme) {
    ui.label(RichText::new("Appearance").strong().color(theme.text));
    ui.horizontal(|ui| {
        ui.radio_value(&mut settings.mode, Mode::Dark, "Dark");
        ui.radio_value(&mut settings.mode, Mode::Light, "Light");
    });
    ui.add_space(12.0);
    ui.label(RichText::new("Wallpaper").strong().color(theme.text));
    ui.horizontal(|ui| {
        for (i, wp) in WALLPAPERS.iter().enumerate() {
            ui.radio_value(&mut settings.wallpaper, i, wp.name);
        }
    });
    ui.add_space(12.0);
    ui.checkbox(&mut settings.show_seconds, "Show seconds in the menu bar");
}

fn monitor_panel(ui: &mut Ui, data: &MonitorData, theme: &Theme, actions: &mut Vec<Action>) {
    ui.label(RichText::new(format!("Frame rate: {:.0} fps", data.fps)).color(theme.text));
    ui.label(
        RichText::new(format!(
            "Uptime: {}:{:02}",
            data.uptime_secs / 60,
            data.uptime_secs % 60
        ))
        .color(theme.text),
    );
    ui.label(RichText::new(format!("Open windows: {}", data.windows.len())).color(theme.text));
    ui.add_space(8.0);
    ui.separator();

    egui::ScrollArea::vertical().show(ui, |ui| {
        for (id, title, minimized) in &data.windows {
            ui.horizontal(|ui| {
                let state = if *minimized { " (minimized)" } else { "" };
                ui.label(RichText::new(format!("{title}{state}")).color(theme.text));
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    if ui.button("Force Quit").clicked() {
                        actions.push(Action::Close(*id));
                    }
                });
            });
        }
    });
}
