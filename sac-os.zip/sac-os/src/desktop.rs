use std::time::{Duration, Instant};

use chrono::Local;
use eframe::egui::{
    self, Align2, Color32, FontId, Id, Key, LayerId, Modifiers, Order, Pos2, Rect, Rounding,
    Sense, Stroke, Vec2,
};

use crate::apps::{self, MonitorData};
use crate::calculator::Calculator;
use crate::theme::{self, Mode, Theme, GREEN, RED, WALLPAPERS, YELLOW};

pub const MENU_BAR_H: f32 = 28.0;
const TITLE_H: f32 = 36.0;
const DOCK_H: f32 = 74.0;
const DOCK_BOTTOM_GAP: f32 = 8.0;
const DOCK_ICON: f32 = 46.0;
const DOCK_SPACING: f32 = 58.0;
const DOCK_MAX_SCALE: f32 = 1.5;
const DOCK_AREA_H: f32 = 130.0;
const MIN_W: f32 = 300.0;
const MIN_H: f32 = 200.0;
const SNAP_EDGE: f32 = 8.0;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum AppKind {
    About,
    Notes,
    Calculator,
    Settings,
    Monitor,
}

impl AppKind {
    pub const ALL: [AppKind; 5] = [
        AppKind::About,
        AppKind::Notes,
        AppKind::Calculator,
        AppKind::Settings,
        AppKind::Monitor,
    ];

    pub fn title(self) -> &'static str {
        match self {
            AppKind::About => "About SAC OS",
            AppKind::Notes => "Notes",
            AppKind::Calculator => "Calculator",
            AppKind::Settings => "Settings",
            AppKind::Monitor => "Activity Monitor",
        }
    }

    fn glyph(self) -> &'static str {
        match self {
            AppKind::About => "i",
            AppKind::Notes => "N",
            AppKind::Calculator => "=",
            AppKind::Settings => "S",
            AppKind::Monitor => "A",
        }
    }

    fn color(self) -> Color32 {
        match self {
            AppKind::About => Color32::from_rgb(10, 132, 255),
            AppKind::Notes => Color32::from_rgb(255, 204, 0),
            AppKind::Calculator => Color32::from_rgb(99, 99, 102),
            AppKind::Settings => Color32::from_rgb(142, 142, 147),
            AppKind::Monitor => Color32::from_rgb(48, 209, 88),
        }
    }

    fn default_size(self) -> Vec2 {
        match self {
            AppKind::About => Vec2::new(460.0, 400.0),
            AppKind::Notes => Vec2::new(520.0, 420.0),
            AppKind::Calculator => Vec2::new(300.0, 420.0),
            AppKind::Settings => Vec2::new(460.0, 330.0),
            AppKind::Monitor => Vec2::new(460.0, 380.0),
        }
    }
}

pub struct Settings {
    pub mode: Mode,
    pub wallpaper: usize,
    pub show_seconds: bool,
}

pub struct Window {
    pub id: u64,
    pub kind: AppKind,
    pub rect: Rect,
    pub restore: Rect,
    pub snapped: bool,
    pub minimized: bool,
    pub notes: String,
    pub calc: Calculator,
}

impl Window {
    pub fn title(&self) -> &'static str {
        self.kind.title()
    }
}

#[derive(Clone, Copy)]
pub enum Action {
    Open(AppKind),
    Focus(u64),
    Close(u64),
    Minimize(u64),
    Zoom(u64),
}

pub struct SacOs {
    windows: Vec<Window>,
    next_id: u64,
    settings: Settings,
    spotlight_open: bool,
    spotlight_query: String,
    spotlight_focus: bool,
    dock_scales: [f32; 5],
    started: Instant,
}

fn icon_center_x(pill: Rect, index: usize) -> f32 {
    pill.left() + 14.0 + DOCK_SPACING * (index as f32 + 0.5)
}

impl SacOs {
    pub fn new(_cc: &eframe::CreationContext<'_>) -> Self {
        let mut app = Self {
            windows: Vec::new(),
            next_id: 1,
            settings: Settings {
                mode: Mode::Dark,
                wallpaper: 0,
                show_seconds: false,
            },
            spotlight_open: false,
            spotlight_query: String::new(),
            spotlight_focus: false,
            dock_scales: [1.0; 5],
            started: Instant::now(),
        };
        let fallback = Rect::from_min_size(Pos2::ZERO, Vec2::new(1280.0, 800.0));
        app.new_window(AppKind::About, fallback);
        app
    }

    fn theme(&self) -> Theme {
        Theme::for_mode(self.settings.mode)
    }

    fn work_area(screen: Rect) -> Rect {
        Rect::from_min_max(
            Pos2::new(screen.left(), screen.top() + MENU_BAR_H),
            Pos2::new(
                screen.right(),
                screen.bottom() - DOCK_H - DOCK_BOTTOM_GAP - 8.0,
            ),
        )
    }

    fn front_id(&self) -> Option<u64> {
        self.windows
            .iter()
            .rev()
            .find(|w| !w.minimized)
            .map(|w| w.id)
    }

    fn window_mut(&mut self, id: u64) -> Option<&mut Window> {
        self.windows.iter_mut().find(|w| w.id == id)
    }

    fn new_window(&mut self, kind: AppKind, screen: Rect) -> u64 {
        let work = Self::work_area(screen);
        let wanted = kind.default_size();
        let size = Vec2::new(wanted.x.min(work.width()), wanted.y.min(work.height()));
        let offset = (self.windows.len() % 8) as f32 * 26.0;
        let min = Pos2::new(work.left() + 90.0 + offset, work.top() + 36.0 + offset);
        let rect = Rect::from_min_size(min, size);
        let id = self.next_id;
        self.next_id += 1;
        self.windows.push(Window {
            id,
            kind,
            rect,
            restore: rect,
            snapped: false,
            minimized: false,
            notes: String::new(),
            calc: Calculator::new(),
        });
        id
    }

    fn open_or_focus(&mut self, kind: AppKind, screen: Rect) {
        let existing = self
            .windows
            .iter()
            .rev()
            .find(|w| w.kind == kind)
            .map(|w| w.id);
        match existing {
            Some(id) => self.focus(id),
            None => {
                self.new_window(kind, screen);
            }
        }
    }

    fn focus(&mut self, id: u64) {
        if let Some(idx) = self.windows.iter().position(|w| w.id == id) {
            let mut w = self.windows.remove(idx);
            w.minimized = false;
            self.windows.push(w);
        }
    }

    fn close(&mut self, id: u64) {
        self.windows.retain(|w| w.id != id);
    }

    fn minimize(&mut self, id: u64) {
        if let Some(w) = self.window_mut(id) {
            w.minimized = true;
        }
    }

    fn zoom(&mut self, id: u64, screen: Rect) {
        let work = Self::work_area(screen);
        if let Some(w) = self.window_mut(id) {
            if w.snapped {
                w.rect = w.restore;
                w.snapped = false;
            } else {
                w.restore = w.rect;
                w.rect = work;
                w.snapped = true;
            }
        }
    }

    /// Drop targets: left edge = left half, right edge = right half, top = maximize.
    fn snap_target(p: Pos2, screen: Rect, work: Rect) -> Option<Rect> {
        let half_left = Rect::from_min_max(
            Pos2::new(screen.left(), work.top()),
            Pos2::new(screen.center().x, work.bottom()),
        );
        let half_right = Rect::from_min_max(
            Pos2::new(screen.center().x, work.top()),
            Pos2::new(screen.right(), work.bottom()),
        );
        if p.x <= screen.left() + SNAP_EDGE {
            Some(half_left)
        } else if p.x >= screen.right() - SNAP_EDGE {
            Some(half_right)
        } else if p.y <= work.top() + SNAP_EDGE {
            Some(work)
        } else {
            None
        }
    }

    /// Cmd+Tab: send the front window to the back.
    fn cycle_windows(&mut self) {
        if let Some(idx) = self.windows.iter().rposition(|w| !w.minimized) {
            let w = self.windows.remove(idx);
            self.windows.insert(0, w);
        }
    }

    fn handle_shortcuts(&mut self, ctx: &egui::Context) {
        let screen = ctx.screen_rect();
        let consume = |mods: Modifiers, key: Key| ctx.input_mut(|i| i.consume_key(mods, key));

        if consume(Modifiers::COMMAND, Key::Space) {
            self.spotlight_open = !self.spotlight_open;
            if self.spotlight_open {
                self.spotlight_query.clear();
                self.spotlight_focus = true;
            }
        }
        if self.spotlight_open && consume(Modifiers::NONE, Key::Escape) {
            self.spotlight_open = false;
        }
        if consume(Modifiers::COMMAND, Key::N) {
            self.new_window(AppKind::Notes, screen);
        }
        if consume(Modifiers::COMMAND, Key::W) {
            if let Some(id) = self.front_id() {
                self.close(id);
            }
        }
        if consume(Modifiers::COMMAND, Key::M) {
            if let Some(id) = self.front_id() {
                self.minimize(id);
            }
        }
        if consume(Modifiers::COMMAND, Key::Comma) {
            self.open_or_focus(AppKind::Settings, screen);
        }
        if consume(Modifiers::COMMAND, Key::Tab) {
            self.cycle_windows();
        }
        if consume(Modifiers::COMMAND | Modifiers::ALT, Key::Escape)
            || consume(Modifiers::CTRL | Modifiers::ALT, Key::Delete)
        {
            self.open_or_focus(AppKind::Monitor, screen);
        }
        if consume(Modifiers::COMMAND, Key::Q) {
            ctx.send_viewport_cmd(egui::ViewportCommand::Close);
        }
    }

    /// Typing goes to the Calculator when it is the front window and no text field has focus.
    fn handle_calculator_keys(&mut self, ctx: &egui::Context) {
        let Some(id) = self.front_id() else { return };
        if ctx.memory(|m| m.focused()).is_some() {
            return;
        }
        let is_calc = self
            .windows
            .iter()
            .any(|w| w.id == id && w.kind == AppKind::Calculator);
        if !is_calc {
            return;
        }
        let events = ctx.input(|i| i.events.clone());
        let Some(win) = self.window_mut(id) else { return };
        for event in events {
            match event {
                egui::Event::Text(text) => {
                    for c in text.chars() {
                        match c {
                            '0'..='9' | '.' => win.calc.digit(c),
                            '+' | '-' | '*' | '/' => win.calc.op(c),
                            '=' => win.calc.equals(),
                            _ => {}
                        }
                    }
                }
                egui::Event::Key {
                    key: Key::Enter,
                    pressed: true,
                    ..
                } => win.calc.equals(),
                egui::Event::Key {
                    key: Key::Backspace,
                    pressed: true,
                    ..
                } => win.calc.backspace(),
                egui::Event::Key {
                    key: Key::Escape,
                    pressed: true,
                    ..
                } => win.calc.clear(),
                _ => {}
            }
        }
    }

    fn draw_background(&self, ctx: &egui::Context) {
        egui::CentralPanel::default()
            .frame(egui::Frame::none())
            .show(ctx, |ui| {
                let rect = ui.max_rect();
                let wp = &WALLPAPERS[self.settings.wallpaper];
                theme::paint_gradient(ui.painter(), rect, wp);
            });
    }

    fn draw_menu_bar(&self, ctx: &egui::Context, actions: &mut Vec<Action>) {
        let theme = self.theme();
        let screen = ctx.screen_rect();
        let bar = Rect::from_min_size(screen.min, Vec2::new(screen.width(), MENU_BAR_H));
        let title = self
            .front_id()
            .and_then(|id| self.windows.iter().find(|w| w.id == id))
            .map(|w| w.title())
            .unwrap_or("Desktop");
        let fmt = if self.settings.show_seconds {
            "%a %b %-d  %-I:%M:%S %p"
        } else {
            "%a %b %-d  %-I:%M %p"
        };
        let clock = Local::now().format(fmt).to_string();

        egui::Area::new(Id::new("menu_bar"))
            .order(Order::Foreground)
            .fixed_pos(bar.min)
            .movable(false)
            .show(ctx, |ui| {
                ui.set_min_size(bar.size());
                ui.set_max_size(bar.size());
                let painter = ui.painter().clone();
                painter.rect_filled(bar, 0.0, theme.bar_bg);

                let logo_rect = Rect::from_min_size(bar.min, Vec2::new(64.0, MENU_BAR_H));
                let logo = ui.interact(logo_rect, Id::new("menu_logo"), Sense::click());
                let logo_color = if logo.hovered() { theme.accent } else { theme.text };
                painter.text(
                    logo_rect.center(),
                    Align2::CENTER_CENTER,
                    "SAC",
                    FontId::proportional(14.0),
                    logo_color,
                );
                if logo.clicked() {
                    actions.push(Action::Open(AppKind::About));
                }

                painter.text(
                    Pos2::new(bar.left() + 80.0, bar.center().y),
                    Align2::LEFT_CENTER,
                    title,
                    FontId::proportional(13.0),
                    theme.text,
                );

                // Right side, laid out from the edge inward.
                // Battery and Wi-Fi are placeholders: no system access here.
                let cy = bar.center().y;
                let clock_rect = painter.text(
                    Pos2::new(bar.right() - 12.0, cy),
                    Align2::RIGHT_CENTER,
                    &clock,
                    FontId::proportional(13.0),
                    theme.text,
                );
                let battery_rect = painter.text(
                    Pos2::new(clock_rect.left() - 18.0, cy),
                    Align2::RIGHT_CENTER,
                    "100%",
                    FontId::proportional(13.0),
                    theme.text,
                );
                painter.text(
                    Pos2::new(battery_rect.left() - 18.0, cy),
                    Align2::RIGHT_CENTER,
                    "Wi-Fi",
                    FontId::proportional(13.0),
                    theme.text,
                );
            });
    }

    fn draw_dock(&mut self, ctx: &egui::Context, actions: &mut Vec<Action>) {
        let theme = self.theme();
        let screen = ctx.screen_rect();
        let count = AppKind::ALL.len();
        let pill_w = count as f32 * DOCK_SPACING + 28.0;
        let pill_bottom = screen.bottom() - DOCK_BOTTOM_GAP;
        let pill = Rect::from_min_max(
            Pos2::new(screen.center().x - pill_w / 2.0, pill_bottom - DOCK_H),
            Pos2::new(screen.center().x + pill_w / 2.0, pill_bottom),
        );
        let area = Rect::from_min_max(
            Pos2::new(pill.left(), screen.bottom() - DOCK_AREA_H),
            Pos2::new(pill.right(), screen.bottom()),
        );

        // Magnification: parabolic falloff around the pointer, eased each frame.
        let pointer = ctx.input(|i| i.pointer.hover_pos());
        let hovering = pointer.map_or(false, |p| area.contains(p));
        for i in 0..count {
            let target = match (hovering, pointer) {
                (true, Some(p)) => {
                    let d = ((icon_center_x(pill, i) - p.x) / (DOCK_SPACING * 2.0)).clamp(-1.0, 1.0);
                    1.0 + (DOCK_MAX_SCALE - 1.0) * (1.0 - d * d)
                }
                _ => 1.0,
            };
            let s = &mut self.dock_scales[i];
            *s += (target - *s) * 0.25;
            if (target - *s).abs() > 0.002 {
                ctx.request_repaint();
            }
        }
        let scales = self.dock_scales;
        let open: Vec<AppKind> = AppKind::ALL
            .iter()
            .copied()
            .filter(|k| self.windows.iter().any(|w| w.kind == *k))
            .collect();

        egui::Area::new(Id::new("dock"))
            .order(Order::Foreground)
            .fixed_pos(area.min)
            .movable(false)
            .show(ctx, |ui| {
                ui.set_min_size(area.size());
                ui.set_max_size(area.size());
                let painter = ui.painter().clone();
                painter.rect_filled(pill, DOCK_H / 2.0, theme.dock_bg);
                painter.rect_stroke(pill, DOCK_H / 2.0, Stroke::new(1.0, theme.border));

                for (i, kind) in AppKind::ALL.iter().enumerate() {
                    let size = DOCK_ICON * scales[i];
                    let cx = icon_center_x(pill, i);
                    let bottom = pill.bottom() - 10.0;
                    let rect = Rect::from_center_size(
                        Pos2::new(cx, bottom - size / 2.0),
                        Vec2::splat(size),
                    );
                    let resp = ui
                        .interact(rect, Id::new(("dock_icon", i)), Sense::click())
                        .on_hover_text(kind.title());
                    painter.rect_filled(rect, size * 0.22, kind.color());
                    painter.text(
                        rect.center(),
                        Align2::CENTER_CENTER,
                        kind.glyph(),
                        FontId::proportional(size * 0.5),
                        Color32::WHITE,
                    );
                    if open.contains(kind) {
                        painter.circle_filled(
                            Pos2::new(cx, pill.bottom() - 4.0),
                            2.5,
                            theme.text,
                        );
                    }
                    if resp.clicked() {
                        actions.push(Action::Open(*kind));
                    }
                }
            });
    }

    fn draw_windows(&mut self, ctx: &egui::Context, actions: &mut Vec<Action>) {
        let theme = self.theme();
        let screen = ctx.screen_rect();
        let work = Self::work_area(screen);
        let front = self.front_id();
        let primary_pressed = ctx.input(|i| i.pointer.primary_pressed());
        let dt = ctx.input(|i| i.stable_dt).max(0.0001);
        let monitor = MonitorData {
            windows: self
                .windows
                .iter()
                .map(|w| (w.id, w.title().to_string(), w.minimized))
                .collect(),
            fps: 1.0 / dt,
            uptime_secs: self.started.elapsed().as_secs(),
        };

        let windows = &mut self.windows;
        let settings = &mut self.settings;

        for win in windows.iter_mut() {
            if win.minimized {
                continue;
            }
            let id = win.id;
            let is_front = front == Some(id);
            let area_id = Id::new(("window", id));
            // Windows are drawn in vector order, so the last one is on top.
            ctx.move_to_top(LayerId::new(Order::Middle, area_id));

            egui::Area::new(area_id)
                .order(Order::Middle)
                .fixed_pos(win.rect.min)
                .movable(false)
                .show(ctx, |ui| {
                    // Title bar: drag, snap on release, double-click to zoom.
                    let bar =
                        Rect::from_min_size(win.rect.min, Vec2::new(win.rect.width(), TITLE_H));
                    let title_resp =
                        ui.interact(bar, Id::new(("title", id)), Sense::click_and_drag());
                    if title_resp.double_clicked() {
                        actions.push(Action::Zoom(id));
                    }
                    if title_resp.dragged() {
                        if win.snapped {
                            win.rect = win.restore;
                            win.snapped = false;
                        }
                        win.rect = win.rect.translate(title_resp.drag_delta());
                    }
                    if title_resp.drag_stopped() {
                        if let Some(p) = title_resp.interact_pointer_pos() {
                            if let Some(target) = Self::snap_target(p, screen, work) {
                                if !win.snapped {
                                    win.restore = win.rect;
                                }
                                win.rect = target;
                                win.snapped = true;
                            }
                        }
                    }

                    let rect = win.rect;
                    let painter = ui.painter().clone();
                    painter.rect_filled(
                        rect.translate(Vec2::new(0.0, 8.0)).expand(4.0),
                        16.0,
                        Color32::from_black_alpha(60),
                    );
                    painter.rect_filled(rect, 12.0, theme.window_bg);
                    let title_rect = Rect::from_min_size(rect.min, Vec2::new(rect.width(), TITLE_H));
                    painter.rect_filled(
                        title_rect,
                        Rounding {
                            nw: 12.0,
                            ne: 12.0,
                            sw: 0.0,
                            se: 0.0,
                        },
                        theme.titlebar_bg,
                    );
                    painter.rect_stroke(rect, 12.0, Stroke::new(1.0, theme.border));

                    // Traffic-light buttons: close, minimize, zoom.
                    let cy = title_rect.center().y;
                    let group_hover = ui.rect_contains_pointer(Rect::from_min_size(
                        title_rect.min,
                        Vec2::new(80.0, TITLE_H),
                    ));
                    for (k, color) in [RED, YELLOW, GREEN].into_iter().enumerate() {
                        let c = Pos2::new(title_rect.left() + 20.0 + k as f32 * 20.0, cy);
                        let light = ui.interact(
                            Rect::from_center_size(c, Vec2::splat(16.0)),
                            Id::new(("light", id, k)),
                            Sense::click(),
                        );
                        let fill = if is_front { color } else { Color32::from_gray(96) };
                        painter.circle_filled(c, 6.5, fill);
                        if is_front && (group_hover || light.hovered()) {
                            let glyph = ["×", "–", "+"][k];
                            painter.text(
                                c,
                                Align2::CENTER_CENTER,
                                glyph,
                                FontId::proportional(10.0),
                                Color32::from_black_alpha(170),
                            );
                        }
                        if light.clicked() {
                            actions.push(match k {
                                0 => Action::Close(id),
                                1 => Action::Minimize(id),
                                _ => Action::Zoom(id),
                            });
                        }
                    }

                    painter.text(
                        title_rect.center(),
                        Align2::CENTER_CENTER,
                        win.title(),
                        FontId::proportional(13.0),
                        if is_front { theme.text } else { theme.subtle },
                    );

                    // Window content.
                    let content = Rect::from_min_max(
                        Pos2::new(rect.left(), rect.top() + TITLE_H),
                        rect.max,
                    )
                    .shrink(12.0);
                    let _ = ui.allocate_ui_at_rect(content, |ui| {
                        apps::render(
                            ui,
                            &mut *win,
                            &monitor,
                            &mut *settings,
                            &theme,
                            &mut *actions,
                        );
                    });

                    if primary_pressed && ui.rect_contains_pointer(rect) {
                        actions.push(Action::Focus(id));
                    }

                    // Bottom-right resize handle, registered last so it wins hit tests.
                    let grip =
                        Rect::from_min_size(rect.max - Vec2::splat(18.0), Vec2::splat(18.0));
                    let grip_resp = ui.interact(grip, Id::new(("grip", id)), Sense::drag());
                    if grip_resp.dragged() {
                        let target = win.rect.max + grip_resp.drag_delta();
                        win.rect.max = Pos2::new(
                            target.x.max(win.rect.left() + MIN_W),
                            target.y.max(win.rect.top() + MIN_H),
                        );
                        win.snapped = false;
                    }
                    for k in 1..=2 {
                        let o = k as f32 * 4.0;
                        painter.line_segment(
                            [
                                Pos2::new(rect.right() - o, rect.bottom() - 2.0),
                                Pos2::new(rect.right() - 2.0, rect.bottom() - o),
                            ],
                            Stroke::new(1.0, theme.subtle),
                        );
                    }
                });
        }
    }

    fn draw_spotlight(&mut self, ctx: &egui::Context, actions: &mut Vec<Action>) {
        let theme = self.theme();
        let screen = ctx.screen_rect();
        let width = 520.0;
        let pos = Pos2::new(screen.center().x - width / 2.0, screen.top() + 120.0);
        let query_lc = self.spotlight_query.to_lowercase();
        let matches: Vec<AppKind> = AppKind::ALL
            .iter()
            .copied()
            .filter(|k| k.title().to_lowercase().contains(&query_lc))
            .collect();
        let enter = ctx.input_mut(|i| i.consume_key(Modifiers::NONE, Key::Enter));
        let focus_now = std::mem::take(&mut self.spotlight_focus);
        let mut query = std::mem::take(&mut self.spotlight_query);
        let mut picked: Option<AppKind> = if enter { matches.first().copied() } else { None };

        egui::Area::new(Id::new("spotlight"))
            .order(Order::Tooltip)
            .fixed_pos(pos)
            .movable(false)
            .show(ctx, |ui| {
                egui::Frame::none()
                    .fill(theme.bar_bg)
                    .rounding(14.0)
                    .stroke(Stroke::new(1.0, theme.border))
                    .inner_margin(egui::Margin::same(12.0))
                    .show(ui, |ui| {
                        ui.set_width(width - 24.0);
                        let edit = ui.add(
                            egui::TextEdit::singleline(&mut query)
                                .id(Id::new("spotlight_input"))
                                .hint_text("Search apps")
                                .font(FontId::proportional(18.0))
                                .desired_width(f32::INFINITY),
                        );
                        if focus_now {
                            edit.request_focus();
                        }
                        for kind in matches.iter().take(6) {
                            let button = egui::Button::new(kind.title());
                            if ui.add_sized([width - 24.0, 30.0], button).clicked() {
                                picked = Some(*kind);
                            }
                        }
                    });
            });

        self.spotlight_query = query;
        if let Some(kind) = picked {
            actions.push(Action::Open(kind));
            self.spotlight_open = false;
        }
    }

    fn apply(&mut self, ctx: &egui::Context, action: Action) {
        let screen = ctx.screen_rect();
        match action {
            Action::Open(kind) => self.open_or_focus(kind, screen),
            Action::Focus(id) => self.focus(id),
            Action::Close(id) => self.close(id),
            Action::Minimize(id) => self.minimize(id),
            Action::Zoom(id) => self.zoom(id, screen),
        }
    }
}

impl eframe::App for SacOs {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.handle_shortcuts(ctx);
        self.handle_calculator_keys(ctx);

        let mut actions = Vec::new();
        self.draw_background(ctx);
        self.draw_windows(ctx, &mut actions);
        self.draw_menu_bar(ctx, &mut actions);
        self.draw_dock(ctx, &mut actions);
        if self.spotlight_open {
            self.draw_spotlight(ctx, &mut actions);
        }
        for action in actions {
            self.apply(ctx, action);
        }

        // Keeps the clock ticking even when nothing else is animating.
        ctx.request_repaint_after(Duration::from_millis(500));
    }
}
