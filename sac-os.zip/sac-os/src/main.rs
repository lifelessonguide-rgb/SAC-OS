mod apps;
mod calculator;
mod desktop;
mod theme;

use eframe::egui;

fn main() -> eframe::Result<()> {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_title("SAC OS")
            .with_inner_size([1280.0, 800.0])
            .with_min_inner_size([900.0, 600.0]),
        ..Default::default()
    };

    eframe::run_native(
        "SAC OS",
        options,
        Box::new(|cc| Ok(Box::new(desktop::SacOs::new(cc)))),
    )
}
