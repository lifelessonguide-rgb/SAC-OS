use eframe::egui::{Color32, Mesh, Painter, Pos2, Rect, Shape};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Mode {
    Dark,
    Light,
}

#[derive(Clone, Copy)]
pub struct Theme {
    pub window_bg: Color32,
    pub titlebar_bg: Color32,
    pub text: Color32,
    pub subtle: Color32,
    pub border: Color32,
    pub bar_bg: Color32,
    pub dock_bg: Color32,
    pub accent: Color32,
}

impl Theme {
    pub fn for_mode(mode: Mode) -> Self {
        match mode {
            Mode::Dark => Self {
                window_bg: Color32::from_rgb(30, 30, 32),
                titlebar_bg: Color32::from_rgb(44, 44, 48),
                text: Color32::from_rgb(236, 236, 242),
                subtle: Color32::from_rgb(142, 142, 147),
                border: Color32::from_white_alpha(30),
                bar_bg: Color32::from_rgba_unmultiplied(20, 20, 22, 200),
                dock_bg: Color32::from_rgba_unmultiplied(50, 50, 56, 170),
                accent: Color32::from_rgb(10, 132, 255),
            },
            Mode::Light => Self {
                window_bg: Color32::from_rgb(248, 248, 250),
                titlebar_bg: Color32::from_rgb(232, 232, 236),
                text: Color32::from_rgb(28, 28, 30),
                subtle: Color32::from_rgb(110, 110, 118),
                border: Color32::from_black_alpha(30),
                bar_bg: Color32::from_rgba_unmultiplied(246, 246, 248, 200),
                dock_bg: Color32::from_rgba_unmultiplied(255, 255, 255, 170),
                accent: Color32::from_rgb(10, 132, 255),
            },
        }
    }
}

pub const RED: Color32 = Color32::from_rgb(0xFF, 0x5F, 0x56);
pub const YELLOW: Color32 = Color32::from_rgb(0xFF, 0xBD, 0x2E);
pub const GREEN: Color32 = Color32::from_rgb(0x27, 0xC9, 0x3F);

pub struct Wallpaper {
    pub name: &'static str,
    pub top: Color32,
    pub mid: Color32,
    pub bottom: Color32,
}

pub const WALLPAPERS: [Wallpaper; 3] = [
    Wallpaper {
        name: "Sequoia",
        top: Color32::from_rgb(38, 94, 186),
        mid: Color32::from_rgb(120, 72, 176),
        bottom: Color32::from_rgb(232, 106, 140),
    },
    Wallpaper {
        name: "Ocean",
        top: Color32::from_rgb(10, 60, 110),
        mid: Color32::from_rgb(20, 130, 150),
        bottom: Color32::from_rgb(120, 220, 200),
    },
    Wallpaper {
        name: "Dusk",
        top: Color32::from_rgb(40, 24, 70),
        mid: Color32::from_rgb(200, 90, 60),
        bottom: Color32::from_rgb(250, 190, 90),
    },
];

/// Paints a three-stop vertical gradient across `rect`.
pub fn paint_gradient(painter: &Painter, rect: Rect, wp: &Wallpaper) {
    let mut mesh = Mesh::default();
    let rows = [
        (rect.top(), wp.top),
        (rect.center().y, wp.mid),
        (rect.bottom(), wp.bottom),
    ];
    for (y, color) in rows {
        mesh.colored_vertex(Pos2::new(rect.left(), y), color);
        mesh.colored_vertex(Pos2::new(rect.right(), y), color);
    }
    mesh.add_triangle(0, 1, 2);
    mesh.add_triangle(1, 3, 2);
    mesh.add_triangle(2, 3, 4);
    mesh.add_triangle(3, 5, 4);
    painter.add(Shape::mesh(mesh));
}
